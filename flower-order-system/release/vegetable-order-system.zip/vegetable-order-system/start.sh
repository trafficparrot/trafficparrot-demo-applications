#!/bin/bash
java -cp .:./lib/* -Dapplication.properties=./application.properties com.trafficparrot.example.OrderVegetablesApplication
